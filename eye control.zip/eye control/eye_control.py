import cv2
import mediapipe as mp
import pyautogui
import numpy as np

pyautogui.FAILSAFE = False

screen_w, screen_h = pyautogui.size()

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(refine_landmarks=True)

cap = cv2.VideoCapture(0)

LEFT_IRIS = [474, 475, 476, 477]
RIGHT_IRIS = [469, 470, 471, 472]

LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]


BLINK_THRESHOLD = 0.23
blink_stage = 0

prev_x, prev_y = screen_w // 2, screen_h // 2
smooth_factor = 10

sensitivity = 2

margin = 50

calibrated = False
center_x, center_y = 0, 0

def eye_ratio(eye_points):
    vertical = np.linalg.norm(np.array(eye_points[1]) - np.array(eye_points[5]))
    horizontal = np.linalg.norm(np.array(eye_points[0]) - np.array(eye_points[3]))
    return vertical / horizontal

def get_iris_center(landmarks, indices, w, h):
    pts = [(int(landmarks[i].x * w), int(landmarks[i].y * h)) for i in indices]
    x = int(sum(p[0] for p in pts) / len(pts))
    y = int(sum(p[1] for p in pts) / len(pts))
    return x, y

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    results = face_mesh.process(rgb)

    if results.multi_face_landmarks:
        for face_landmarks in results.multi_face_landmarks:

          
            left_iris = get_iris_center(face_landmarks.landmark, LEFT_IRIS, w, h)
            right_iris = get_iris_center(face_landmarks.landmark, RIGHT_IRIS, w, h)

            iris_x = (left_iris[0] + right_iris[0]) // 2
            iris_y = (left_iris[1] + right_iris[1]) // 2

            if not calibrated:
                center_x, center_y = iris_x, iris_y
                calibrated = True

            dx = iris_x - center_x
            dy = iris_y - center_y

            target_x = prev_x + dx * sensitivity
            target_y = prev_y + dy * sensitivity

            target_x = np.clip(target_x, margin, screen_w - margin)
            target_y = np.clip(target_y, margin, screen_h - margin)

            final_x = prev_x + (target_x - prev_x) / smooth_factor
            final_y = prev_y + (target_y - prev_y) / smooth_factor

            pyautogui.moveTo(final_x, final_y)

            prev_x, prev_y = final_x, final_y

            left_eye = [(int(face_landmarks.landmark[i].x * w),
                         int(face_landmarks.landmark[i].y * h)) for i in LEFT_EYE]

            right_eye = [(int(face_landmarks.landmark[i].x * w),
                          int(face_landmarks.landmark[i].y * h)) for i in RIGHT_EYE]

            avg_ratio = (eye_ratio(left_eye) + eye_ratio(right_eye)) / 2

            if avg_ratio < BLINK_THRESHOLD:
                if blink_stage == 0:
                    blink_stage = 1
                elif blink_stage == 2:
                    pyautogui.click()
                    print("CLICK")
                    blink_stage = 0
            else:
                if blink_stage == 1:
                    blink_stage = 2

            cv2.putText(frame, f'Ratio: {avg_ratio:.2f}', (30, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            cv2.circle(frame, (iris_x, iris_y), 4, (0, 0, 255), -1)

    cv2.imshow("Eye Mouse Control", frame)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()