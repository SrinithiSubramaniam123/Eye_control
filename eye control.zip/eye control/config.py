# eye_control/config.py

# Camera settings
CAMERA_INDEX = 0   # default webcam

# Blink detection thresholds
BLINK_RATIO_THRESHOLD = 5.0

# Mouse settings
CURSOR_SPEED = 1.5  # multiplier for cursor movement

# Other constants
FRAME_WIDTH = 640
FRAME_HEIGHT = 480