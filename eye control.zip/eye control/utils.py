# eye_control/utils.py
import cv2
import pyautogui
import numpy as np

# Calculate Eye Aspect Ratio for blink detection
def eye_aspect_ratio(eye_points):
    A = np.linalg.norm(eye_points[1] - eye_points[5])
    B = np.linalg.norm(eye_points[2] - eye_points[4])
    C = np.linalg.norm(eye_points[0] - eye_points[3])
    ear = (A + B) / (2.0 * C)
    return ear

# Move mouse smoothly
def move_cursor(x, y, speed=1.0):
    screen_w, screen_h = pyautogui.size()
    target_x = int(x * screen_w)
    target_y = int(y * screen_h)
    pyautogui.moveTo(target_x, target_y, duration=0.1 * speed)

# Convert normalized coordinates from camera to screen
def normalize_coordinates(x, y, frame_width, frame_height):
    norm_x = x / frame_width
    norm_y = y / frame_height
    return norm_x, norm_y

# Optional: simple smoothing function
def smooth_point(prev_point, new_point, alpha=0.2):
    smoothed = (1 - alpha) * prev_point + alpha * new_point
    return smoothed